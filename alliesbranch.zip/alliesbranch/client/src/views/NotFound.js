import React from 'react';

const NotFound = () => {
        return "Page not found"
}

export default NotFound;
